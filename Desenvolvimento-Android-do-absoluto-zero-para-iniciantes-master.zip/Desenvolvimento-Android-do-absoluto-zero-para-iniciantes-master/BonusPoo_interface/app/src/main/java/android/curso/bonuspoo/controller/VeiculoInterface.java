package android.curso.bonuspoo.controller;

/**
 * Created by marcomaddo on 27/10/2017.
 */

public interface VeiculoInterface {

    public void opcionalGPS();

    public void opcionalArCondicionado();

}
