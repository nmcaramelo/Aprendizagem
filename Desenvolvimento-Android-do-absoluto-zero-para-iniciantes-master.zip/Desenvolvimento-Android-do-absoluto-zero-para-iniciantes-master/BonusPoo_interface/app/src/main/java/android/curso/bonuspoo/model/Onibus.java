package android.curso.bonuspoo.model;

import android.curso.bonuspoo.controller.VeiculoInterface;

/**
 * Created by marcomaddo on 27/10/2017.
 */

public class Onibus extends Fabricante implements VeiculoInterface {

    @Override
    public void opcionalGPS() {

    }

    @Override
    public void opcionalArCondicionado() {

    }
}
