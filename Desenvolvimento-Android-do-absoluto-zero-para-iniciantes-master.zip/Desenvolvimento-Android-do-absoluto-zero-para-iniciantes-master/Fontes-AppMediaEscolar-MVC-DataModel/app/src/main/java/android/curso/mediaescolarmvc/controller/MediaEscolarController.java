package android.curso.mediaescolarmvc.controller;

/**
 * Created by marcomaddo on 04/11/2017.
 */

public class MediaEscolarController {


    public void calcularMedia()
    {

    }

    public void resultadoFinal(){

    }

}
