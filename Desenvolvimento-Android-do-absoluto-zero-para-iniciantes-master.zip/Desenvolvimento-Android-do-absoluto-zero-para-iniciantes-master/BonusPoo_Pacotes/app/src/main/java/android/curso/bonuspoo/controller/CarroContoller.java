package android.curso.bonuspoo.controller;

/**
 * Created by marcomaddo on 27/10/2017.
 */

public class CarroContoller {

    // regras de negócios
}
