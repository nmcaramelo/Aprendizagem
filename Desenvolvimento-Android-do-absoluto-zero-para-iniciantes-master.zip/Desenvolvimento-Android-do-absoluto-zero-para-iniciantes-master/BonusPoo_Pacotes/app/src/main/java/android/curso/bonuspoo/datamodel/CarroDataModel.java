package android.curso.bonuspoo.datamodel;

/**
 * Created by marcomaddo on 27/10/2017.
 */

public class CarroDataModel {

    // definições da tabela.
}
