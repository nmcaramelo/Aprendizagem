package android.curso.bonuspoo.datasource;

/**
 * Created by marcomaddo on 27/10/2017.
 */

public class datasource {

    // integração do Banco de Dados com o app
    // CRUD
    // Incluir
    // Alterar
    // Deletar
    // Listar
}
